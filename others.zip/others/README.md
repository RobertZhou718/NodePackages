# generator-sharepoint

This is a [Yeoman](http://yeoman.io/) plugin for use with the SharePoint Framework.
Using this generator, developers can quickly set up a new client-side web part
project with sensible defaults and best practices.

*This package is part of the [SharePoint Framework](http://aka.ms/spfx),
which is a collection of NPM packages that empower developers to create client-side experiences
for [Microsoft SharePoint](https://products.office.com/en-us/sharepoint/collaboration).
For more information, including complete API documentation and code samples, please visit
the [SharePoint Framework](http://aka.ms/spfx) web site.*
