import { BaseGenerator, IBaseOptions } from '../../common/BaseGenerator';
import * as BaseComponent from '../component/BaseComponentGenerator';
export declare type AvailableExtensions = 'ApplicationCustomizer' | 'CommandSet' | 'FieldCustomizer' | 'SearchQueryModifier' | 'FormCustomizer';
export interface IBaseExtensionOptions extends BaseComponent.IBaseComponentOptions {
}
export interface IBaseExtensionContext extends BaseComponent.IBaseComponentContext {
}
export declare function defineOptions<TOptions extends IBaseOptions, TContext>(generator: BaseGenerator<TOptions, TContext>, type?: string): void;
export declare abstract class BaseExtensionGenerator<IOptions extends IBaseExtensionOptions, IContext extends IBaseExtensionContext> extends BaseComponent.BaseComponentGenerator<IOptions, IContext> {
    protected readonly folderName: string;
    configuring(): void;
    writing(shouldCopy?: boolean): void;
    install(): void;
    protected abstract includeClientSideInstances(): boolean;
    protected addFeature(): void;
    protected hasElementsXml(): boolean;
    private _getFeatureFrameworkDocsUrl;
}
//# sourceMappingURL=BaseExtensionGenerator.d.ts.map