import { BaseGenerator, IBaseOptions } from '../../common/BaseGenerator';
import * as ApplicationCustomizer from '../applicationCustomizer';
import * as CommandSet from '../commandSet';
import * as FieldCustomizer from '../fieldCustomizer';
import * as BaseExtension from './BaseExtensionGenerator';
import * as FormCustomizer from '../formCustomizer';
export interface IExtensionOptions extends FieldCustomizer.IFieldCustomizerOptions, CommandSet.ICommandSetOptions, ApplicationCustomizer.IApplicationCustomizerOptions, FormCustomizer.IFormCustomizerOptions {
    extensionType: BaseExtension.AvailableExtensions;
}
export declare function defineOptions<TOptions extends IBaseOptions, TContext>(generator: BaseGenerator<TOptions, TContext>): void;
export declare function composeWith<TOptions extends IBaseOptions, TContext>(base: BaseGenerator<TOptions, TContext>, options: IBaseOptions): void;
/**
 * This class selects between multiple different types of extensions for instantiation.
 */
export declare class ExtensionSelectorGenerator extends BaseGenerator<IExtensionOptions, {}> {
    readonly friendlyName: string;
    initializing(): void;
    prompting(): Promise<void>;
    configuring(): void;
    writing(): void;
    install(): void;
    end(): void;
    protected constructor(args: string | string[], options: IExtensionOptions);
    private shouldExecute;
}
//# sourceMappingURL=index.d.ts.map