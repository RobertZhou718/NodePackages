import { IBaseOptions, BaseGenerator, AvailableTemplates } from '../../common/BaseGenerator';
import * as BaseComponent from '../component/BaseComponentGenerator';
export interface IWebpartOptions extends BaseComponent.IBaseComponentOptions {
}
export interface IWebpartContext extends BaseComponent.IBaseComponentContext {
}
export declare function composeWith<TOptions extends IBaseOptions, TContext>(base: BaseGenerator<TOptions, TContext>, options: IBaseOptions): void;
export declare function defineOptions<TOptions extends IBaseOptions, TContext>(generator: BaseGenerator<TOptions, TContext>): void;
export declare class WebpartGenerator extends BaseComponent.BaseComponentGenerator<IWebpartOptions, IWebpartContext> {
    protected readonly friendlyName: string;
    protected readonly codeName: string;
    protected readonly allowedTemplates: AvailableTemplates[];
    protected readonly folderName: string;
    initializing(): void;
    prompting(): Promise<void>;
    configuring(): void;
    writing(): void;
    install(): void;
    end(): void;
    protected constructor(args: string | string[], options: IWebpartOptions);
    private shouldExecute;
}
//# sourceMappingURL=index.d.ts.map