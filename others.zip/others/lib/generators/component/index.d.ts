import { IBaseOptions, BaseGenerator } from '../../common/BaseGenerator';
import * as Webpart from '../webpart';
import * as Extension from '../extension';
import * as AdaptiveCardExtension from '../adaptiveCardExtension';
export interface IComponentSelectorOptions extends Webpart.IWebpartOptions, Extension.IExtensionOptions, AdaptiveCardExtension.IACEOptions {
    componentType: 'webpart' | 'extension' | 'library' | 'adaptiveCardExtension';
}
export declare function composeWith<TOptions extends IBaseOptions, TContext>(base: BaseGenerator<TOptions, TContext>, options: IBaseOptions): void;
export declare function defineOptions<TOptions extends IBaseOptions, TContext>(generator: BaseGenerator<TOptions, TContext>): void;
/**
 * This class selects between multiple different types of components for instantiation.
 */
export declare class ComponentSelectorGenerator extends BaseGenerator<IComponentSelectorOptions, {}> {
    readonly friendlyName: string;
    initializing(): void;
    prompting(): Promise<void>;
    configuring(): void;
    writing(): void;
    install(): void;
    end(): void;
    private shouldExecute;
}
//# sourceMappingURL=index.d.ts.map