import { IConfigBundle } from '@microsoft/spfx-heft-plugins';
import { AvailableTemplates, BaseGenerator, IBaseOptions } from '../../common/BaseGenerator';
declare type ESLintProfiles = 'react' | 'default';
export interface IBaseComponentShared {
    /**
     * @deprecated use {@link template} instead.
     */
    framework: AvailableTemplates;
    template: AvailableTemplates;
    componentDescription: string;
}
export interface IBaseComponentOptions extends IBaseComponentShared, IBaseOptions {
    componentName: string;
    creatingSolution: boolean;
}
export interface IBaseComponentContext extends IBaseComponentShared {
    componentId: string;
    componentName: string;
    componentNameCamelCase: string;
    componentClassName: string;
    componentClassNameKebabCase: string;
    componentAlias: string;
    componentStrings: string;
    componentNameUnescaped: string;
    eslintProfile: ESLintProfiles;
}
export declare function defineOptions<TOptions extends IBaseOptions, TContext>(generator: BaseGenerator<TOptions, TContext>, type: string): void;
export declare abstract class BaseComponentGenerator<IOptions extends IBaseComponentOptions, IContext extends IBaseComponentContext> extends BaseGenerator<IOptions, IContext> {
    /** The friendly name of this component, which appears in the UI */
    protected abstract readonly friendlyName: string;
    /** The class extension of the component. Is used for the alias in manifest and class name in templates */
    protected abstract readonly codeName: string;
    /** The name of the folder that this comonent should have its template copied to */
    protected abstract readonly folderName: string;
    protected abstract readonly allowedTemplates: AvailableTemplates[];
    private _shouldLogESLintWarning;
    prompting(): Promise<void>;
    configuring(bundleEntry?: IConfigBundle): void;
    writing(shouldWrite?: boolean): void;
    install(): void;
    end(): void;
    protected _getOutputFolder(componentNameCamelCase: string): string;
    private checkSolution;
}
export interface INormalizedComponentNames {
    componentNameUnescaped: string;
    componentName: string;
    componentNameCamelCase: string;
    componentClassName: string;
    componentStrings: string;
    componentClassNameKebabCase: string;
    componentAlias: string;
}
export declare function normalizeComponentNames(componentNameUnescaped: string, componentType: string): INormalizedComponentNames;
export {};
//# sourceMappingURL=BaseComponentGenerator.d.ts.map