declare interface I<%= componentStrings %> {
  Command1: string;
  Command2: string;
}

declare module '<%= componentStrings %>' {
  const strings: I<%= componentStrings %>;
  export = strings;
}
