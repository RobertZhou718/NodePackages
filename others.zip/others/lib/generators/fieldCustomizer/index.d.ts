import { IBaseOptions, BaseGenerator, AvailableTemplates } from '../../common/BaseGenerator';
import * as BaseExtension from '../extension/BaseExtensionGenerator';
export interface IFieldCustomizerOptions extends BaseExtension.IBaseExtensionOptions {
}
export interface IFieldCustomizerContext extends BaseExtension.IBaseExtensionContext {
    fieldId: string;
}
export declare function composeWith<TOptions extends IBaseOptions, TContext>(base: BaseGenerator<TOptions, TContext>, options: IBaseOptions): void;
export declare function defineOptions<TOptions extends IBaseOptions, TContext>(generator: BaseGenerator<TOptions, TContext>): void;
export declare class FieldCustomizerGenerator extends BaseExtension.BaseExtensionGenerator<IFieldCustomizerOptions, IFieldCustomizerContext> {
    protected readonly friendlyName: string;
    protected readonly codeName: string;
    protected readonly allowedTemplates: AvailableTemplates[];
    initializing(): void;
    prompting(): Promise<void>;
    configuring(): void;
    writing(): void;
    install(): void;
    end(): void;
    protected constructor(args: string | string[], options: IFieldCustomizerOptions);
    protected includeClientSideInstances(): boolean;
    private shouldExecute;
}
//# sourceMappingURL=index.d.ts.map