import { BaseGenerator, IBaseOptions } from '../../common/BaseGenerator';
export interface ISolutionOptions extends IBaseOptions {
    solutionName: string;
    solutionShortDescription: string;
    skipFeatureDeployment: boolean;
    environment: 'spo';
    packageManager: 'npm' | 'pnpm' | 'yarn';
    isDomainIsolated: boolean;
    useHeft: boolean;
}
export interface ISolutionContext extends ISolutionOptions {
    libraryName: string;
    libraryId: string;
    version: string;
    versionBadge: string;
}
export declare function composeWith<TOptions extends IBaseOptions, TContext>(base: BaseGenerator<TOptions, TContext>, options: IBaseOptions): void;
export declare function defineOptions(generator: BaseGenerator<ISolutionOptions, ISolutionContext>): void;
//# sourceMappingURL=index.d.ts.map