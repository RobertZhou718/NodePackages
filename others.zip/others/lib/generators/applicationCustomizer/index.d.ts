import { BaseGenerator, AvailableTemplates } from '../../common/BaseGenerator';
import * as BaseExtension from '../extension/BaseExtensionGenerator';
import { IBaseOptions } from '../../common/BaseGenerator';
export interface IApplicationCustomizerOptions extends BaseExtension.IBaseExtensionOptions {
}
export interface IApplicationCustomizerContext extends BaseExtension.IBaseExtensionContext {
}
export declare function composeWith<TOptions extends IBaseOptions, TContext>(base: BaseGenerator<TOptions, TContext>, options: IBaseOptions): void;
export declare function defineOptions<TOptions extends IBaseOptions, TContext>(generator: BaseGenerator<TOptions, TContext>): void;
export declare class ApplicationCustomizerGenerator extends BaseExtension.BaseExtensionGenerator<IApplicationCustomizerOptions, IApplicationCustomizerContext> {
    protected readonly friendlyName: string;
    protected readonly codeName: string;
    protected readonly allowedTemplates: AvailableTemplates[];
    initializing(): void;
    prompting(): Promise<void>;
    configuring(): void;
    writing(): void;
    install(): void;
    end(): void;
    protected constructor(args: string | string[], options: IApplicationCustomizerOptions);
    protected includeClientSideInstances(): boolean;
    private shouldExecute;
}
//# sourceMappingURL=index.d.ts.map