import { BaseGenerator, IBaseOptions } from '../../common/BaseGenerator';
import * as Solution from '../solution';
import * as Component from '../component';
export interface IAppContext {
    creatingSolution: boolean;
}
export interface IAppOptions extends IBaseOptions, Solution.ISolutionOptions, Component.IComponentSelectorOptions {
}
export declare function composeWith<TOptions extends IBaseOptions, TContext>(base: BaseGenerator<TOptions, TContext>, options: IAppOptions): void;
//# sourceMappingURL=index.d.ts.map