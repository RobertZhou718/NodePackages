import * as React from 'react';
import { Log, FormDisplayMode } from '@microsoft/sp-core-library';
import { FormCustomizerContext } from '@microsoft/sp-listview-extensibility';

import styles from './<%= componentName %>.module.scss';

export interface I<%= componentName %>Props {
  context: FormCustomizerContext;
  displayMode: FormDisplayMode;
  onSave: () => void;
  onClose: () => void;
}

const LOG_SOURCE: string = '<%= componentName %>';

export default class <%= componentName %> extends React.Component<I<%= componentName %>Props, {}> {
  public componentDidMount(): void {
    Log.info(LOG_SOURCE, 'React Element: <%= componentName %> mounted');
  }

  public componentWillUnmount(): void {
    Log.info(LOG_SOURCE, 'React Element: <%= componentName %> unmounted');
  }

  public render(): React.ReactElement<{}> {
    return <div className={styles.<%= componentNameCamelCase %>} />;
  }
}
