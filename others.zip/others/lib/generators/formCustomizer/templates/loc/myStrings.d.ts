declare interface I<%= componentStrings %> {
  Save: string;
  Cancel: string;
  Close: string;
}

declare module '<%= componentStrings %>' {
  const strings: I<%= componentStrings %>;
  export = strings;
}
