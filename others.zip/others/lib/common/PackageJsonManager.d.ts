import { IPackageJson } from '@rushstack/node-core-library';
import { Editor } from 'mem-fs-editor';
import { JsonManager } from './JsonManager';
export interface IExtendedPackageJson extends IPackageJson {
    resolutions?: {
        [key: string]: string;
    };
}
export declare class PackageJsonManager extends JsonManager<IExtendedPackageJson> {
    private static _instance;
    static load(filepath: string, fs: Editor): void;
    static reset(): void;
    static get instance(): PackageJsonManager;
    addDependency(dependency: string, version: string): void;
    addDevDependency(dependency: string, version: string): void;
    addResolution(dependency: string, resolution: string): void;
}
//# sourceMappingURL=PackageJsonManager.d.ts.map