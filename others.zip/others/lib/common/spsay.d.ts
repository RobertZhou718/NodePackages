export default function spsay(solutionName: string, useHeft: boolean): string;
//# sourceMappingURL=spsay.d.ts.map