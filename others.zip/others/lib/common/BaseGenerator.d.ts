import yeoman from 'yeoman-generator';
import { Editor } from 'mem-fs-editor';
import { IPackageJson } from '@rushstack/node-core-library';
import { PackageJsonManager } from './PackageJsonManager';
import { ConfigJsonManager } from './ConfigJsonManager';
import { ServeJsonManager } from './ServeJsonManager';
import { PackageSolutionJsonManager } from './PackageSolutionJsonManager';
export declare type AvailableTemplates = 'react' | 'none' | 'minimal';
export declare type DependencyGroups = keyof typeof import('./dependencies.json');
export interface IBaseOptions {
    'skip-install': boolean;
    plusbeta: boolean;
    force?: boolean;
}
export declare abstract class BaseGenerator<IOptions extends IBaseOptions, IContext> extends yeoman<IOptions> {
    protected static generatorPackageJson: IPackageJson;
    private static _hasCheckedForUpdates;
    /**
     * The context property bag used by templates
     */
    context: IContext;
    protected abstract friendlyName: string;
    protected allowEmptyPackageJson: boolean;
    private _dependenciesByDependencyGroup;
    protected get packageJsonManager(): PackageJsonManager;
    protected get configJson(): ConfigJsonManager;
    protected get serveJson(): ServeJsonManager;
    protected get packageSolutionJson(): PackageSolutionJsonManager;
    private static _checkForUpdates;
    /**
     * Lifecycle events, these are called in a specific order by the Yeoman
     * generator, which is why they are listed here in order.
     * http://yeoman.io/authoring/running-context.html
     */
    /** Your initialization methods (checking current project state, getting configs, etc) */
    abstract initializing(): Promise<void> | void;
    /** Where you prompt users for options (where you'd call this.prompt()) */
    abstract prompting(): Promise<void> | void;
    /** Saving configurations and configure the project (creating metadata files) */
    abstract configuring(): Promise<void> | void;
    copyTemplate: Editor['copy'];
    /** Where you write the generator specific files (routes, controllers, etc) */
    writing(shouldCopy?: boolean): Promise<void> | void;
    /** Where installation are run (npm, bower) */
    abstract install(): Promise<void> | void;
    /** Called last, cleanup, say good bye, etc */
    abstract end(): Promise<void> | void;
    protected constructor(args: string | string[], options: IOptions);
    protected tryInstall(): boolean;
    protected ensureCorrectFolder(): void;
    protected ensureDependencyGroup(group: DependencyGroups): void;
    protected nameIsDependencyGroup(name: string): name is DependencyGroups;
    private _ensureDependenciesByDependencyGroup;
    private _addResolutionsIfApplicable;
    private _doPnpmInstall;
    private _untokenizedCopier;
}
//# sourceMappingURL=BaseGenerator.d.ts.map