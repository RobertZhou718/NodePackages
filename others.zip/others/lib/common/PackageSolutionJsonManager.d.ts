import { IPackageSolution } from '@microsoft/spfx-heft-plugins';
import { Editor } from 'mem-fs-editor';
import { ISolutionContext } from '../generators/solution';
import { JsonManager } from './JsonManager';
export declare class PackageSolutionJsonManager extends JsonManager<Partial<IPackageSolution>> {
    private static _instance?;
    static load(filepath: string, fs: Editor): void;
    static reset(): void;
    static get instance(): PackageSolutionJsonManager;
    getSkipFeatureDeployment(): boolean;
    setUpSolution(solutionContext: ISolutionContext): void;
    addExtensionFeature(featureId: string, includeClientSideInstance: boolean): void;
    addFeature(featureId: string, title: string, description: string, includeAssets: boolean, includeClientSideInstance?: boolean): void;
    /**
     * Returns the existing feature that doesn't have componentIds.
     * We can use the same feature to add additional elements
     */
    private _tryGetFeatureToReuse;
}
//# sourceMappingURL=PackageSolutionJsonManager.d.ts.map