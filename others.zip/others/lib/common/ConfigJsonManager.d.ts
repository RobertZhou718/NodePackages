import { Editor } from 'mem-fs-editor';
import { IConfigBundle, IConfigJson } from '@microsoft/spfx-heft-plugins';
import { IV1ConfigJson } from '@microsoft/spfx-heft-plugins/lib/spfxConfig/interfaces/config-v1';
import { JsonManager } from './JsonManager';
export declare class ConfigJsonManager extends JsonManager<IConfigJson | IV1ConfigJson> {
    configJsonIsV1: boolean;
    private static _instance?;
    static load(filepath: string, fs: Editor): void;
    static reset(): void;
    static get instance(): ConfigJsonManager;
    addEntry(bundleEntry: IConfigBundle, name: string): void;
    addLocalizedResource(localizedResourceKey: string, localizedResourcePath?: string): void;
    private constructor();
    private _translateV2BundleIntoV1;
}
//# sourceMappingURL=ConfigJsonManager.d.ts.map