import { Editor } from 'mem-fs-editor';
export declare abstract class JsonManager<T> {
    protected _filepath: string;
    protected _fs: Editor;
    protected _data: T;
    set(newData: T): T;
    merge(newData: Partial<T>): T;
    get data(): T;
    save(): void;
    protected constructor(_filepath: string, _fs: Editor, _data: T);
}
//# sourceMappingURL=JsonManager.d.ts.map