export interface IYeomanConfigurationData {
    set: (key: string, params: Object) => void;
    get: <T>(key: string) => T;
}
/**
 * This class wraps an untyped property bag with types for
 * the generator.
 */
export declare class YeomanConfiguration {
    private static _store;
    static setStore(yeomanConfiguration: IYeomanConfigurationData): void;
    static get libraryName(): string;
    static set libraryName(value: string);
    static get version(): string;
    static set version(value: string);
    static get libraryId(): string;
    static set libraryId(value: string);
    static get environment(): 'spo';
    static set environment(value: 'spo');
    static get packageManager(): 'npm' | 'pnpm' | 'yarn';
    static set packageManager(value: 'npm' | 'pnpm' | 'yarn');
    static get useHeft(): boolean;
    static set useHeft(value: boolean);
}
//# sourceMappingURL=YeomanConfiguration.d.ts.map