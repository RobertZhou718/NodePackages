import { Editor } from 'mem-fs-editor';
import { _ISpfxServeSessionConfiguration as ISpfxServeSessionConfiguration, _ISpfxServe as ISpfxServe } from '@microsoft/spfx-heft-plugins';
import { JsonManager } from './JsonManager';
export declare class ServeJsonManager extends JsonManager<ISpfxServe> {
    private static _instance?;
    static load(filepath: string, fs: Editor): void;
    static reset(): void;
    static get instance(): ServeJsonManager;
    addConfiguration(name: string, configuration: ISpfxServeSessionConfiguration): void;
    setUpForWebParts(): void;
}
//# sourceMappingURL=ServeJsonManager.d.ts.map